Zippy wordmark pack (play-dot version): lockup = speed-play icon + "Zippy"

android/res/drawable/
  ic_zippy_lockup.xml    icon + name, 110x30dp default (viewport 178x48, aspect 3.7:1)
  ic_zippy_wordmark.xml  name only, 76x28dp default
  ic_zippy_glyph.xml     speed-play icon only, 26x20dp default, tight bounds (the launcher foreground has extra padding)
All three are single-color vectors drawn in black. Tint them in code; do not hardcode colors. autoMirrored is false so they never flip in RTL.

Compose (top bar):
  Icon(
      painter = painterResource(R.drawable.ic_zippy_lockup),
      contentDescription = "Zippy",
      tint = MaterialTheme.colorScheme.onBackground,   // or onSurface if the bar uses surface
      modifier = Modifier.height(28.dp)                // width follows the aspect ratio
  )

svg/   zippy-lockup / wordmark / glyph in black and white, transparent background
png/   transparent PNGs, lockup 1602x432, wordmark 1224x456, glyph 1008x768 (black and white)
zippy-lockup-preview.png   preview on white and dark backgrounds
